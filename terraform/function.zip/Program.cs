﻿using FaceDetector;

await new Handler().FunctionHandler(null!, null!);
